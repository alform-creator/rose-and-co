window.ROSE_CONTACT = { phone: '+37433081898', whatsapp: '37495806009', instagram: 'https://www.instagram.com/rose___co/' };
